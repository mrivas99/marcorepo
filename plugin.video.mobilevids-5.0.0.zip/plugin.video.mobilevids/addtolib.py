import xbmc, xbmcgui
import xbmcaddon
import xbmcvfs
import json
import re
import os

makeFile = xbmcvfs.mkdir
openFile = xbmcvfs.File

# name and create our window 
class DownloadFile(): 
    # and define it as self
    def __init__(self):
    # add picture control to our window (self) with a hardcoded path name to picture
        baseUrl = sys.argv[1]
        title = sys.argv[2]
        foldername = sys.argv[3]      
        clean_title = "";
        
        content = 'plugin://plugin.video.mobilevids/?action=play_item&item_id=' + baseUrl+"&title="+ title
        folder = os.path.join("special://userdata/addon_data/plugin.video.mobilevids/", foldername + "/")
        folder = xbmc.makeLegalFilename(folder)
        makeFile(folder)
        if foldername == 'TVShows':
            content = 'plugin://plugin.video.mobilevids/?action=play_tvitem&item_id=' + baseUrl+"&title="+ title
            clean_title = sys.argv[4]
            folder = os.path.join("special://userdata/addon_data/plugin.video.mobilevids/", foldername + "/" + clean_title + "/Episodes/")
            folder = xbmc.makeLegalFilename(folder)    
            makeFile(folder)
            
        path = xbmc.makeLegalFilename( folder + self.legal_filename(title) + '_.strm')
        
        file = openFile(path, 'w')
        file.write(str(content))
        file.close()
        
        dialog = xbmcgui.Dialog()
        i = dialog.ok("Sync finsihed", "Syncronization off " + foldername + " has finished.\nMobilevids addon will now try to update your library.")     
        self.execute_json_rpc("VideoLibrary.Scan")# UPDATES LIBRARY
    
    def execute_json_rpc(self, method, **params):
        ''' Execute a JSON-RPC command with specified method and params (as keyword arguments)
        See https://kodi.wiki/view/JSON-RPC_API/v8#Methods for methods and params '''
        return json.loads(
            xbmc.executeJSONRPC(
                json.dumps({
                    'jsonrpc': '2.0',
                    "method": method,
                    "params": params,
                    'id': 1
                })
            )
        )  
    
    def strmFile(self, i):
        try:
            baseUrl, title, foldername = i['baseUrl'], i['title'], i['foldername']
            
            folder = os.path.join("special://userdata/addon_data/plugin.video.mobilevids/Movies", foldername)
            self.write_file(os.path.join(folder, self.legal_filename(title) + '.strm'), content)            
        except:
            pass

        
    @staticmethod
    def legal_filename(filename):
        try:
            filename = filename.strip()
            filename = re.sub(r'(?!%s)[^\w\-_\.]', '.', filename)
            filename = re.sub('\.+', '.', filename)
            filename = re.sub(re.compile('(CON|PRN|AUX|NUL|COM\d|LPT\d)\.', re.I), '\\1_', filename)
            xbmc.makeLegalFilename(filename)
            return filename
        except:
            return filename
    
    @staticmethod
    def write_file(path, content):
        try:
            path = xbmc.makeLegalFilename(path)
            if not isinstance(content, basestring):
                content = str(content)

            file = openFile(path, 'w')
            file.write(str(content))
            file.close()
        except Exception as e:
            pass     
            
# store our window as a short variable for easy of use
W = DownloadFile()
# run our window we created with our background jpeg image