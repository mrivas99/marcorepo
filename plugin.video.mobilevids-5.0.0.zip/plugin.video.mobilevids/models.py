from collections import namedtuple

Item = namedtuple('Item', ['id', 'title', 'clean_title','genres', 'url','vip','mvstream','mvstream2','is_serie', 'poster_url', 'plot','duration', 'rating','DBID','season','number'])
Message = namedtuple('Message', ['id', 'title', 'message', 'date'])
Episode = namedtuple('Episode', ['id', 'season', 'episode', 'url'])
Season = namedtuple('Seasons', ['serie_id', 'season_number', 'episodes'])
