import urllib
import mobilevids

import json
import logging
import xbmcaddon,xbmcgui
import os
import xbmcvfs
import re
import sys
import shutil
import sqlite3

makeFile = xbmcvfs.mkdir
openFile = xbmcvfs.File
class CustomDialog(xbmcgui.WindowXMLDialog):
    def __init__(self,xbmc,*args,**kwargs):
        self.xbmc = kwargs.get('kodi','')
        self.caption = kwargs.get('caption','')
        self.text = kwargs.get('text','')
        xbmcgui.WindowXMLDialog.__init__(self)

    def onInit(self):
        self.getControl(100).setLabel(self.caption)
        self.getControl(200).setText(self.text)        
        self.getControl(300).setLabel("Close")
        self.xbmc.executebuiltin('Control.SetFocus(%d, %d)' % (300, 0));
        
class Navigation(object):

    def __init__(self, xbmc, xbmcplugin, xbmcgui, argv):
        self.xbmc = xbmc        
        self.xbmcplugin = xbmcplugin
        self.xbmcgui = xbmcgui               
                       
        
        
        self.plugin_url = argv[0]
        self.handle = int(argv[1])
        
        logging.warning("Setting handle: " + str(argv[1]))
        try:
            self.params = Navigation.decode_parameters(argv[2])
        except:
            self.params = None
            
    def showTextDialog(self,caption,text):
        path = xbmcaddon.Addon().getAddonInfo('path')
        win = CustomDialog('dialog.xml',path,'Dialog',caption=caption,text=text,kodi=self.xbmc)
        win.doModal()
        del win
    
    @staticmethod
    def encode_parameters(params):
        quoted_params = []
        for key in params:
            value = unicode(params[key])
            if isinstance(params[key], dict):
                value = json.dumps(params[key])
            if isinstance(params[key], list):
                value = json.dumps(params[key])
            quoted_params.append((urllib.quote(key), urllib.quote(value.encode('unicode_escape'))))
        return "?" + "&".join(["%s=%s" % (a, b) for a, b in quoted_params])

    @staticmethod
    def decode_parameters(parameters):
        query = parameters[1:]
        params = query.split('&')
        result = {}
        for p in params:
            key, value = p.split('=')
            key = urllib.unquote(key)
            value = urllib.unquote(value).decode('utf-8')
            result[key] = value
        return result

    def add_listing_menu_item(self, caption, listing_type, page=0):
        params = {'action': 'listing', 'type': listing_type, 'page': page,'gui': 1}
        url = self.plugin_url + Navigation.encode_parameters(params)
        self.xbmc.log('url: ' + url, self.xbmc.LOGERROR)

        list_item = self.xbmcgui.ListItem(caption)
        list_item.setInfo(type="Video", infoLabels={
            "Title": caption,
            
        })
        runner = "XBMC.RunScript(special://home/addons/plugin.video.mobilevids/addMultipletolib.py, " +str(listing_type) +")"        
        commands = []
        if listing_type == 4:
            commands.append(( str("Add & Sync against Movies Library" + str(listing_type)), runner, ))   
        elif listing_type == 5:
            commands.append(( str("Add & Sync against TVShows Library" + str(listing_type)), runner, ))
        list_item.addContextMenuItems(commands)
        
        return self.xbmcplugin.addDirectoryItem(handle=self.handle, url=url,
                                                listitem=list_item,
                                                isFolder=True)

    def add_menu_item(self, caption, action, page=0, search=None):
        params = {'action': action, 'page': page, 'title': caption,'gui': 1}
        if search:
            params['search'] = search
        url = self.plugin_url + Navigation.encode_parameters(params)
        self.xbmc.log('url: ' + url, self.xbmc.LOGERROR)
 
        list_item = self.xbmcgui.ListItem(caption)
        list_item.setInfo(type="Video", infoLabels={
            "Title": caption,
        })
        


        return self.xbmcplugin.addDirectoryItem(handle=self.handle, url=url,
                                                listitem=list_item,
                                                isFolder=True)

    def add_movie_list_item(self, item):
        action = 'play_item'
        params = {
            'action': action,
            'id': item.id,
            'item_id': item.id,
            'gui': 1
        }
        action_url = self.plugin_url + Navigation.encode_parameters(params)
        list_item = self.xbmcgui.ListItem(item.title)
        runner = "XBMC.RunScript(special://home/addons/plugin.video.mobilevids/addtolib.py, " + str(item.id) + ", "+ str(item.title)+ ", Movies)"
        commands = []
        commands.append(( str("[MV] Add to Movies library"), runner, ))      
        list_item.addContextMenuItems(commands)
            
        if item.poster_url == "None":
            my_addon = xbmcaddon.Addon('plugin.video.mobilevids')
            list_item.setIconImage(my_addon.getAddonInfo('icon'))		
            list_item.setArt({ 'poster': my_addon.getAddonInfo('icon'), 'fanart' : my_addon.getAddonInfo('icon'), 'thumb' : my_addon.getAddonInfo('icon') })
        else:
            list_item.setArt({ 'poster': item.poster_url, 'fanart' : item.poster_url, 'thumb' : item.poster_url })		
        list_item.setInfo(type='Video', infoLabels={'Title': item.title, 'genre': item.genres, 'plot': item.plot, 'Duration': item.duration, 'UserRating': item.rating})
        return self.xbmcplugin.addDirectoryItem(handle=self.handle,
                                                url=action_url,
                                                listitem=list_item,
                                                isFolder=False)

    def add_season_list_item(self, title, serie_id, season_index, season_number):
        params = {
            'action': 'list_episodes',
            'serie_id': serie_id,
            'season_index': season_index,
            'title': title,
            'gui': 1
        }
        
        action_url = self.plugin_url + Navigation.encode_parameters(params)
        list_item = self.xbmcgui.ListItem(title)
        runner = "XBMC.RunScript(special://home/addons/plugin.video.mobilevids/addMultipletolib.py, 0, " +str(serie_id) +")"        
        commands = []
        commands.append(( str("[MV] - Sync with TVShows Library" ), runner, ))
        list_item.addContextMenuItems(commands)

        return self.xbmcplugin.addDirectoryItem(handle=self.handle,
                                                url=action_url,
                                                listitem=list_item,
                                                isFolder=True)
                                                
                                                
    def add_sport_list_item(self, title, serie_id):
        params = {
            'action': 'list_episodes_sports',
            'serie_id': serie_id,            
            'title': title,
            'gui': 1
        }
        
        action_url = self.plugin_url + Navigation.encode_parameters(params)
        list_item = self.xbmcgui.ListItem(title)
        return self.xbmcplugin.addDirectoryItem(handle=self.handle,
                                                url=action_url,
                                                listitem=list_item,
                                                isFolder=True)
    
    def add_anime_list_item(self, title, serie_id):
        params = {
            'action': 'list_episodes_anime',
            'serie_id': serie_id,            
            'title': title,
            'gui': 1
        }
        
        action_url = self.plugin_url + Navigation.encode_parameters(params)
        list_item = self.xbmcgui.ListItem(title)
        return self.xbmcplugin.addDirectoryItem(handle=self.handle,
                                                url=action_url,
                                                listitem=list_item,
                                                isFolder=True)                                                
    def add_live_list_item(self, item):
        params = {
            'action': 'play_live',
            'url' : item.url,
            'title': item.title,
            'gui': 1
        }
        
        action_url = self.plugin_url + Navigation.encode_parameters(params)
        list_item = self.xbmcgui.ListItem(item.title)
        return self.xbmcplugin.addDirectoryItem(handle=self.handle,
                                                url=action_url,
                                                listitem=list_item,
                                                isFolder=False)    
                                                
    def add_episode_list_item(self, item, episode, isSportsOrAnim):
        logging.warning("LOADING FROM EPISODE")
        params = {
            'action': 'play_tvitem',
            'title': item.title,
            'season_number':0,
            'episode_number':0,
            'gui': 1,
            'item_id': item.id
        }		   
		
        name = episode.title
        action_url = self.plugin_url + Navigation.encode_parameters(params)
        list_item = self.xbmcgui.ListItem(name)        
        runner = "XBMC.RunScript(special://home/addons/plugin.video.mobilevids/addtolib.py, " + str(item.id) + ", "+ str(item.title)+ ", TVShows, "+str(item.clean_title) +")"
        commands = []
        commands.append(( str("[MV] Add to TVShows library"), runner, ))      
        list_item.addContextMenuItems(commands)
        
        if item.poster_url == "None":
            my_addon = xbmcaddon.Addon('plugin.video.mobilevids')
            list_item.setIconImage(my_addon.getAddonInfo('icon'))		
            list_item.setArt({ 'poster': my_addon.getAddonInfo('icon'), 'fanart' : my_addon.getAddonInfo('icon'), 'thumb' : my_addon.getAddonInfo('icon') })
        else:
            list_item.setArt({ 'poster': item.poster_url, 'fanart' : item.poster_url, 'thumb' : item.poster_url })		
        list_item.setInfo(type='Video', infoLabels={'Title': item.title, 'genre': item.genres, 'plot': item.plot, 'Duration': item.duration, 'UserRating': item.rating})
        return self.xbmcplugin.addDirectoryItem(handle=self.handle,
                                                url=action_url,
                                                listitem=list_item,
                                                isFolder=True)
    def add_epizode_list_item(self,item):
        logging.warning("LOADING FROM EPIZODE")	
        action = 'play_tvitem'
        params = {
            'action': action,
            'item_id': item.id,
            'id': item.id,
            'gui': 1,
            }
        name = item.title
        action_url = self.plugin_url + Navigation.encode_parameters(params)
              
        list_item = self.xbmcgui.ListItem(name)
        if item.poster_url == "None":
            my_addon = xbmcaddon.Addon('plugin.video.mobilevids')
            list_item.setIconImage(my_addon.getAddonInfo('icon'))		
            list_item.setArt({ 'poster': my_addon.getAddonInfo('icon'), 'fanart' : my_addon.getAddonInfo('icon'), 'thumb' : my_addon.getAddonInfo('icon') })
        else:
            list_item.setArt({ 'poster': item.poster_url, 'fanart' : item.poster_url, 'thumb' : item.poster_url })		
        list_item.setInfo(type='Video', infoLabels={'Title': item.title, 'genre': item.genres, 'plot': item.plot, 'Duration': item.duration, 'UserRating': item.rating})
        return self.xbmcplugin.addDirectoryItem(handle=self.handle,
                                                url=action_url,
                                                listitem=list_item,
                                                isFolder=False)
                                                
    def add_genre_item(self, genre, index, serie):
        params = {
            'action': 'list_genre',
            'genre_index': index,
            'serie': serie,
            'gui': 1
        }
        action_url = self.plugin_url + Navigation.encode_parameters(params)
        list_item = self.xbmcgui.ListItem(genre)
        
       
      
            
        return self.xbmcplugin.addDirectoryItem(handle=self.handle,
                                                url=action_url,
                                                listitem=list_item,
                                                isFolder=True)

    def build_main_menu(self):
        self.add_menu_item('Search', 'search')
        for listing_type, name in mobilevids.LISTING_NAMES:
            self.add_listing_menu_item(name, listing_type, page=0)
            

        self.add_menu_item("Movies", "list_az")
        self.add_menu_item("Tv Shows", "list_shows")
        self.add_menu_item("Sports", "list_serie_genres_sports")
        self.add_menu_item("Anime", "list_serie_genres_anime")
        
        self.add_menu_item("Tools", "tools_menu")
        
        

        return self.xbmcplugin.endOfDirectory(self.handle)

    def buildaz(self):
        self.add_menu_item("0-9", "list_a-z")
        self.add_menu_item("A-B", "list_a-z")
        self.add_menu_item("C-D", "list_a-z")
        self.add_menu_item("E-F", "list_a-z")
        self.add_menu_item("G-H", "list_a-z")
        self.add_menu_item("I-J", "list_a-z")
        self.add_menu_item("K-L", "list_a-z")
        self.add_menu_item("M-N", "list_a-z")
        self.add_menu_item("O-P", "list_a-z")
        self.add_menu_item("Q-R", "list_a-z")
        self.add_menu_item("S-T", "list_a-z")
        self.add_menu_item("U-V", "list_a-z")
        self.add_menu_item("W-X", "list_a-z")
        self.add_menu_item("Y-Z", "list_a-z")		
        return self.xbmcplugin.endOfDirectory(self.handle)
   
    def search(self, text, page):
        if not page:
            kb = self.xbmc.Keyboard('', 'Search', False)
            kb.doModal()
            if kb.isConfirmed():
                text = kb.getText()
            else:
                return
        items = mobilevids.search(text,"",page)
        for item in items:
            if item.is_serie:
             self.add_season_list_item(item.title,item.id,0,1)
            else:
             self.add_movie_list_item(item)
        return self.xbmcplugin.endOfDirectory(self.handle)
		
    def searchnb(self, text, letters):
        items = mobilevids.search(text,letters, 0)
        for item in items:
            self.add_movie_list_item(item)
        return self.xbmcplugin.endOfDirectory(self.handle)
		
    def play_movie(self, title, players_data):
        try:
            players = json.loads(players_data)
            streams = mobilevids.streams_from_player_url(players[0]['url'])
            subtitles = mobilevids.subtitles_from_url(players[0]['url'])
            return self.select_stream(title, streams, subtitles)
        except Exception, e:
            print str(e)
            dialog = self.xbmcgui.Dialog()
            dialog.ok("Error", "Failed to open stream")

    def select_stream(self, title, streams, subtitles):

        # Ask user which stream to use
        url = self.quality_select_dialog(streams)
        if url is None:
            return
        return self.play_stream(title, url, subtitles)
    
    def setWatchedStatus(self,item):
        try:
            filename = self.legal_filename(item.title) + '_.strm'
            db_path = self.xbmc.translatePath(os.path.join("special://userdata/Database"))  + "/MyVideos107.db"
            query = "UPDATE files SET playCount=1 WHERE strFilename LIKE '%"+filename+"%'"
            logging.warning("QUERY " + str(query))
        
            conn = sqlite3.connect(db_path)
            c = conn.cursor()
            c.execute(query)       
            conn.commit()
            conn.close()
        except:
            return
    
    
        
    
    def play_stream(self, title, stream, content,item):
        li = self.xbmcgui.ListItem(label=title, path=stream)
        if item != "" :        
            self.setWatchedStatus(item)
            li.setUniqueIDs({ 'imdb': item.DBID} )
            if content == 'movie':
                li.setInfo(type='movie', infoLabels={"Title": title,'playcount': 1,'plot':item.plot,'imdbnumber': item.DBID})        
            elif content == 'tv':
                li.setInfo(type='episode', infoLabels={"Title": title,'playcount': 1,'plot':item.plot,'season': item.season, 'episode': item.number,'imdbnumber': item.DBID})
            
        
       
        #li.setSubtitles(subtitles)       
        try:
            if int(self.params["gui"]) == 1:
                self.xbmc.Player().play(item=stream, listitem=li)
            else:
                self.xbmcplugin.setResolvedUrl(self.handle, succeeded=True, listitem=li)
        except:
                self.xbmcplugin.setResolvedUrl(self.handle, succeeded=True, listitem=li)
        
        return 

    def list_movie_parts(self, title, players_data):
        players = json.loads(players_data)
        for player in players:
            params = {
                'action': 'play_movie_part',
                'title': title,
                'url': player['url'],
                'gui': 1
            }
            name = player['title']
            action_url = self.plugin_url + Navigation.encode_parameters(params)
            list_item = self.xbmcgui.ListItem(name)
            list_item.setInfo(type='Video', infoLabels={'Title': name})
            self.xbmcplugin.addDirectoryItem(handle=self.handle,
                                             url=action_url,
                                             listitem=list_item,
                                             isFolder=False)
        return self.xbmcplugin.endOfDirectory(self.handle)

    def play_movie_part(self, title, player_url):
        try:
            streams = mobilevids.streams_from_player_url(player_url)
            subtitles = mobilevids.subtitles_from_url(player_url)
            return self.select_stream(title, streams, subtitles)
        except Exception, e:
            dialog = self.xbmcgui.Dialog()
            print 'EEEE'
            print str(e)
            dialog.ok("Error", "Failed to open stream: %s" % player_url)

    def play_episode(self, title, season_number, episode_number, url):
        try:
            streams = mobilevids.streams_from_player_url(url)

            subtitles = mobilevids.subtitles_from_url(url)
            name = '%s S%sE%s' % (title, season_number, episode_number)
            return self.select_stream(name, streams, subtitles)
        except Exception, e:
            print 'EEEE'
            print str(e)
            dialog = self.xbmcgui.Dialog()
            return dialog.ok("Error", "Failed to open stream: %s" % url)


    def list_seasons(self, serie_id, title, isSportsOrAnim):
        seasons = mobilevids.list_seasons(serie_id, isSportsOrAnim)
        for idx, season in enumerate(seasons):
            self.add_season_list_item(title, season.serie_id, idx, season.season_number)
        return self.xbmcplugin.endOfDirectory(self.handle)

    def list_episodes(self, title, serie_id, season_index, isSportsOrAnim):
        items = mobilevids.list_seasons(serie_id, isSportsOrAnim)
        for item in items:
            self.add_episode_list_item(item,item, isSportsOrAnim)
        return self.xbmcplugin.endOfDirectory(self.handle)
        
    def list_show(self, title, serie_id, season_index, isSportsOrAnim):
        items = mobilevids.list_seasons(serie_id, isSportsOrAnim)
        for item in items:
            self.add_season_list_item(item.title,item.id, isSportsOrAnim,0)
        return self.xbmcplugin.endOfDirectory(self.handle)
    
    def list_sports(self):
        items = mobilevids.list_seasons(0, 1)
        for item in items:
            self.add_sport_list_item(item.title,item.id)
        return self.xbmcplugin.endOfDirectory(self.handle)      
    
    def list_animes(self):
        items = mobilevids.list_seasons(0, 2)
        for item in items:
            self.add_anime_list_item(item.title,item.id)
        return self.xbmcplugin.endOfDirectory(self.handle)      
        
        
		
    def list_episodez(self, title, serie_id, season_index, isSportsOrAnim):
        seasons = mobilevids.list_seasons(serie_id, isSportsOrAnim)
        for item in seasons:
            self.add_epizode_list_item(item)
        return self.xbmcplugin.endOfDirectory(self.handle)

    def list_movie_genres(self):
        for idx, genre in enumerate(mobilevids.GENRES):
            self.add_genre_item(genre, idx, serie=0)
        return self.xbmcplugin.endOfDirectory(self.handle)

    def list_serie_genres(self):
        for idx, genre in enumerate(mobilevids.GENRES):
            self.add_genre_item(genre, idx, serie=1)
        return self.xbmcplugin.endOfDirectory(self.handle)

    def list_serie_genres_sports(self):
        for idx, genre in enumerate(mobilevids.GENRES):
            self.add_genre_item(genre, idx, serie=1)
        return self.xbmcplugin.endOfDirectory(self.handle)	

    def list_genre(self, serie, genre_index, page=0):
        genre = mobilevids.GENRES[genre_index]
        items = mobilevids.list_genre(genre, serie, page)
        for item in items:
            self.add_movie_list_item(item)

        # TODO: Refactor add_menu_item structure
        params = {
            'action': 'list_genre',
            'genre_index': genre_index,
            'serie': serie,
            'page': page + 1,
            'gui': 1
        }
        name = 'Next'
        action_url = self.plugin_url + Navigation.encode_parameters(params)
        list_item = self.xbmcgui.ListItem(name)
        list_item.setInfo(type='Video', infoLabels={'Title': name})
        self.xbmcplugin.addDirectoryItem(handle=self.handle,
                                         url=action_url,
                                         listitem=list_item,
                                         isFolder=True)

        return self.xbmcplugin.endOfDirectory(self.handle)

    def listing(self, type, page=0):
        items = mobilevids.listing(type, page)
        for item in items:
            if item.is_serie:

                self.add_episode_list_item(item,item,0)
            else:
                self.add_movie_list_item(item)
        
        return self.xbmcplugin.endOfDirectory(self.handle)
    
    def listing_live(self, type, page=0):
        items = mobilevids.listing(type, page)
        for item in items:
            self.add_live_list_item(item)

        return self.xbmcplugin.endOfDirectory(self.handle)
    def quality_select_dialog(self, stream_urls):
        sorted_urls = sorted(stream_urls, key=lambda s: mobilevids.natural_sort_key(s[0]))
        qualities = [s[0] for s in sorted_urls]
        dialog = self.xbmcgui.Dialog()
        answer = 0
        if len(qualities) > 1:
            answer = dialog.select("Quality Select", qualities)
            if answer == -1:
                return
        url = sorted_urls[answer][1].strip()
        return url
    def execute_json_rpc(self, method, **params):
        ''' Execute a JSON-RPC command with specified method and params (as keyword arguments)
        See https://kodi.wiki/view/JSON-RPC_API/v8#Methods for methods and params '''
        return json.loads(
            self.xbmc.executeJSONRPC(
                json.dumps({
                    'jsonrpc': '2.0',
                    "method": method,
                    "params": params,
                    'id': 1
                })
            )
        )
        
    @staticmethod
    def legal_filename(filename):
        try:
            filename = filename.strip()
            filename = re.sub(r'(?!%s)[^\w\-_\.]', '.', filename)
            filename = re.sub('\.+', '.', filename)
            filename = re.sub(re.compile('(CON|PRN|AUX|NUL|COM\d|LPT\d)\.', re.I), '\\1_', filename)
            xbmc.makeLegalFilename(filename)
            return filename
        except:
            return filename
            
    def dispatch(self):
        if not self.params:
            
            
            messages = mobilevids.getMessages()
            msg_text = ""
            for msg in messages:
                msg_text = msg_text + "["+msg.date+"]: "+ msg.title +"\n" + msg.message + "\n\n";
            
            
            if msg_text != "":
                self.showTextDialog("Mobilevids News",msg_text)
            
            
            
            
            
            
            #CHECK UPS AND MESSAGES
            if mobilevids.user_details_available() == False:
                    self.showTextDialog("Account details required","Please input your username and password into addon settings.\nOn computers press C or right click while addon is active and then choose settings.\nOn Phones/Tablets/TV-Boxes long press the addon.\n\n\nNote: This addon only works with VIP accounts.")
                    return self.xbmcplugin.endOfDirectory(self.handle)
            
            if mobilevids.checkFirstRun() == True:
                    message = "Welcome both new and old members!\n\nThe mobilevids addon has overgone some major changes, thanks to your feedback and commitment to this community. So What's new then you ask?\n"
                    message = message +  "\nI'm glad you asked. Here is the changes made to this update.\n" 
                    message = message +  "- Added the ability to sync MV content with Kodis built-in video library with autosync possiblity on startup.\n"
                    message = message +  "    - Just bring out the context menu and either a movie or tv show and choose Sync MV content\n"
                    message = message +  "      Remeber to enable 'AutoSync on startup' in Addon Settings\n"
                    message = message +  "- Added the ability to choose video quality (SD AND HD). Especially good for those slow connections/low bandwith\n"
                    message = message +  "- Added Tools menu option: Here you can Export all MV movies to Kodi Library\n"
                    message = message +  "    - Show library paths: Showes which two folders you need to add to your video sources.\n"
                    message = message +  "    - Library Update: Updates the Kodi video library to sync with new content.\n"
                    message = message +  "    - Library Clean: Cleans up some of the mess you might make.Generally a good idea when things are synced and still don't show up in kodi library\n"
                    message = message +  "    - Delete Movies/TVShows Library: Will delete all synced content. Only do this if you want a refresh.\n"
                    
                    self.showTextDialog("Welcome to Mobilevids Addon.",message)                    
            
            return self.build_main_menu()
        if 'action' in self.params:
            action = self.params['action']
            page = int(self.params.get('page', 0))
            logging.warning("=============> ACTION: " + action + " Handle: " + str(self.handle));            
            if action == 'search':
                return self.search(self.params.get('search', None), page)

            if action == 'listing':
                if self.params['type'] == '7': # Live channels                    
                    return self.listing_live(7)
                
                
                
                if self.params['type'] == '8':
                    items = mobilevids.listing(int(self.params['type']), 1)
                    for item in items:
                        content = 'plugin://plugin.video.mobilevids/?action=play_item&item_id=' + item.id
                        folder = os.path.join("special://userdata/addon_data/plugin.video.mobilevids/Movies/")
                        folder = self.xbmc.makeLegalFilename(folder)
                        makeFile(folder)                                    
                        path = self.xbmc.makeLegalFilename( folder + self.legal_filename(item.title) + 'strm')
        
                        file = openFile(path, 'w')
                        file.write(str(content))
                        file.close()
                    self.execute_json_rpc("VideoLibrary.Scan")# UPDATES LIBRARY
                    dialog = xbmcgui.Dialog()
                    i = dialog.ok("Adding movies", "Movies are now syncronized.")  
                    return self.build_main_menu()                    
                if self.params['type'] == '9':
                    items = mobilevids.listing(int(self.params['type']), 1)
                    for item in items:
                        content = 'plugin://plugin.video.mobilevids/?action=play_tvitem&item_id=' + item.id
                        folder = os.path.join("special://userdata/addon_data/plugin.video.mobilevids/TVShows/")
                        folder = self.xbmc.makeLegalFilename(folder)
                        makeFile(folder)
                        folder = os.path.join("special://userdata/addon_data/plugin.video.mobilevids/TVShows/" + item.clean_title + "/Episodes/")
                        folder = self.xbmc.makeLegalFilename(folder)    
                        makeFile(folder)            
                        path = self.xbmc.makeLegalFilename( folder + self.legal_filename(item.title) + 'strm')        
                        file = openFile(path, 'w')
                        file.write(str(content))
                        file.close()
                    self.execute_json_rpc("VideoLibrary.Scan"); # UPDATES LIBRARY
                    dialog = xbmcgui.Dialog()
                    i = dialog.ok("Adding tvshows", "TVShows are now syncronized")
                    return self.build_main_menu()
                return self.listing(int(self.params['type']), int(self.params['page']))
            if action == 'play_movie':
                logging.warning("PLAYING VIDEO WITH PATH: " + self.params['url'])      
                self.play_stream(self.params['title'],self.params['url'],"movie","") 
                return self.xbmcplugin.endOfDirectory(self.handle)
                
            if action == 'play_item':
                logging.warning("========= HANDLE " + mobilevids.vid_quality + " GET HANDLE: ")
                item = mobilevids.getSingle(self.params['item_id'])[0]
                if mobilevids.auto_select_quality == "true":
                    if int(mobilevids.vid_quality) > 0:
                          self.play_stream(item.title,item.vip,"movie",item)
                    else:
                          self.play_stream(item.title,item.url,"movie",item)
                    return
                formats = []
                if item.url != '':
                    formats.append(("[VIP] HD", item.url))
                if item.vip != '':
                    formats.append(("[VIP] SD", item.vip))                  
                url = self.quality_select_dialog(formats)
                if url is None:
                    return
                logging.warning("PLAYING MOVIE ITEM WITH URL: " + str(url))
                self.play_stream(item.title,url,"movie",item)
                return 
                
                
            if action == 'play_tvitem':
            
                item = mobilevids.getSingleTv(self.params['item_id'])[0]
                if mobilevids.auto_select_quality == "true":
                    if int(mobilevids.vid_quality) > 0:
                          self.play_stream(item.title,item.vip,"tv",item)
                    else:
                          self.play_stream(item.title,item.url,"tv",item)
                    return

                formats = []
                if item.url != '':
                    formats.append(("[VIP] HD", item.url))
                if item.vip != '':
                    formats.append(("[VIP] SD", item.vip))
                url = self.quality_select_dialog(formats)
                if url is None:
                    return
                logging.warning("PLAY TV ITEM: " + str(url))      
                self.play_stream(item.title,url,"tv",item)
                return 
            if action == 'play_live':
      
                self.play_stream(self.params['title'],self.params['url'],"tv","")
                return     
                
               
            if action == 'list_movie_parts':
                return self.list_movie_parts(self.params['title'], self.params['players'])
            if action == 'list_seasons':
                return self.list_seasons(self.params['id'],
                                         self.params['title'],0)
            if action == 'list_episodes':
                return self.list_episodes(self.params['title'],
                                          int(self.params['serie_id']),
                                          int(self.params['season_index']), 0)
            if action == 'list_episodes_sports':
                    return self.list_episodes(self.params['title'],
                                          int(self.params['serie_id']),
                                          0, 1)
            if action == 'list_episodes_anime':            
                    return self.list_episodes(self.params['title'],
                                          int(self.params['serie_id']),
                                          0, 2)
            if action == 'list_az':
                return self.buildaz()
            if action == 'list_a-z':
                return self.searchnb(self.params['title'], self.params['title'])

            if action == 'list_movies':
                return self.searchnb(self.params['title'], "")
            if action == 'list_shows':
                return self.list_show("0",0,0,0)
            
            if action == 'tools_menu':
                self.add_listing_menu_item("Export Movies To Library", 8, page=0)
                self.add_menu_item("Library Setup Guide", "library_paths")
                self.add_menu_item("Library Update", "library_update")
                self.add_menu_item("Library Clean", "library_clean")
                
                
                self.add_menu_item("Delete Movies Library", "library_delete_movie")
                self.add_menu_item("Delete TVShows Library", "library_delete_tv")

                return self.xbmcplugin.endOfDirectory(self.handle)
            if action == 'library_update':
                self.execute_json_rpc("VideoLibrary.Scan")# UPDATES LIBRARY    
            if action == 'library_clean':
                self.execute_json_rpc("VideoLibrary.Clean")# UPDATES LIBRARY
            if action == 'library_delete_tv':
                folder = self.xbmc.translatePath(os.path.join("special://userdata/addon_data/plugin.video.mobilevids/TVShows"))
                shutil.rmtree(folder, ignore_errors=True)
                dialog = self.xbmcgui.Dialog()
                dialog.ok("Info", "TVShows library is now deleted.")
                
            if action == 'library_delete_movie':
                folder = self.xbmc.translatePath(os.path.join("special://userdata/addon_data/plugin.video.mobilevids/Movies"))
                shutil.rmtree(folder, ignore_errors=True)
                dialog = self.xbmcgui.Dialog()
                dialog.ok("Info", "Movies library is now deleted.")
            if action == 'library_paths':
                movies_path = "special://userdata/addon_data/plugin.video.mobilevids/Movies"       
                shows_path = "special://userdata/addon_data/plugin.video.mobilevids/TVShows"   
                self.showTextDialog("Library Setup Guide",'If you want to sync MV addon to your library go to Settings-Media Settings-Library.\nClick on Videos then Add Videos and click where it says <None>.\nHere you need to input each one of the following paths: \n\nFor Movies:\n' + str(movies_path) + "\nFor TVShows:\n" + str(shows_path) + "\n\nNow Press OK and select the content type for the directory either Movies or TV Shows and leave all other settings as they are.\nPress OK again and select Yes when asked if you want to refresh the information for all items in this path.\nAllow Kodi to scan the folders and when its done movies and tv shows should start popping up in Kodi home items Movies and Tv Shows" )
                
            if action == 'list_serie_genres_sports':
                return self.list_sports()
            if action == 'list_serie_genres_anime':
                return self.list_animes()				
            if action == 'list_genre':
                return self.list_genre(int(self.params['serie']),
                                       int(self.params['genre_index']),
                                       int(self.params.get('page', 0)))
            if action == 'list_tvlist':
                return self.list_episodez(self.params['title'],int(self.params['item_id']),0,0)
            if action == 'list_sportslist':
                return self.list_episodez(self.params['title'],int(self.params['id']),0,1)
            if action == 'list_animlist':
                return self.list_episodez(self.params['title'],int(self.params['id']),0,2)				
            if action == 'play_movie_part':
                return self.play_movie_part(self.params['title'],
                                            self.params['url'])
