import time
import xbmc
import mobilevids
import xbmcvfs
import re
import os,sys
import xbmcaddon
import simplejson as json
makeFile = xbmcvfs.mkdir
openFile = xbmcvfs.File

def execute_json_rpc(method, **params):
    ''' Execute a JSON-RPC command with specified method and params (as keyword arguments)
    See https://kodi.wiki/view/JSON-RPC_API/v8#Methods for methods and params '''
    return json.loads(
        xbmc.executeJSONRPC(
            json.dumps({
                'jsonrpc': '2.0',
                "method": method,
                "params": params,
                'id': 1
            })
        )
    )
    
def legal_filename(filename):
    try:
        filename = filename.strip()
        filename = re.sub(r'(?!%s)[^\w\-_\.]', '.', filename)
        filename = re.sub('\.+', '.', filename)
        filename = re.sub(re.compile('(CON|PRN|AUX|NUL|COM\d|LPT\d)\.', re.I), '\\1_', filename)
        xbmc.makeLegalFilename(filename)
        return filename
    except:
        return filename 

if __name__ == '__main__':
    monitor = xbmc.Monitor()
    
    while not monitor.abortRequested():
        
        if monitor.waitForAbort(10): # Half an hour in seconds
            # Abort was requested while waiting. We should exit
            break
        if mobilevids.sync_with_library != "true":
            xbmc.log("Mobilevids Library skipped sync %s" % time.time(), level=xbmc.LOGNOTICE)
            break;
        items = mobilevids.listing(4, 1)
        
        for item in items:
            content = 'plugin://plugin.video.mobilevids/?action=play_item&item_id=' + item.id
            folder = os.path.join("special://userdata/addon_data/plugin.video.mobilevids/Movies/")
            folder = xbmc.makeLegalFilename(folder)
            makeFile(folder)
            
            path = xbmc.makeLegalFilename( folder + legal_filename(item.title) + '_.strm')        
            file = openFile(path, 'w')
            file.write(str(content))
            file.close()
            
        items2 = mobilevids.listing(5, 1)
        for item in items2:
            content = 'plugin://plugin.video.mobilevids/?action=play_tvitem&item_id=' + item.id
            folder = os.path.join("special://userdata/addon_data/plugin.video.mobilevids/TVShows/")
            folder = xbmc.makeLegalFilename(folder)
            makeFile(folder)
            folder = os.path.join("special://userdata/addon_data/plugin.video.mobilevids/TVShows/" + item.clean_title + "/Episodes/")
            folder = xbmc.makeLegalFilename(folder)    
            makeFile(folder)            
            path = xbmc.makeLegalFilename( folder + legal_filename(item.title) + '_.strm')        
            file = openFile(path, 'w')
            file.write(str(content))
            file.close()                
            
            
        execute_json_rpc("VideoLibrary.Scan"); # UPDATES LIBRARY
        xbmc.log("Mobilevids Library Sync Done: %s" % time.time(), level=xbmc.LOGNOTICE)
        xbmc.sleep(1800000)